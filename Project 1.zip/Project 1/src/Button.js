import React, { Component } from 'react';


// class Button extends Component

// {
//     render()
//     {

    
//     return (

       
//         <button> Add to cart </button>
       
//     );
// }

// }
// export default Button;