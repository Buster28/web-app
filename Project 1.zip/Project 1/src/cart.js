
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

class Cart extends Componemt{
    render()
    {
        return (
            <div>
                <p> Hello There </p>
                </div>

        )
    }
}
ReactDOM.render(<Cart/>, document.getElementById('cart'));